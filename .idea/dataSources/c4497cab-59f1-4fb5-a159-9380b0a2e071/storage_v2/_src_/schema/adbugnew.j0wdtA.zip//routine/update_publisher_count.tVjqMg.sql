create
    definer = adbug@`%` procedure update_publisher_count(IN publisher_id int)
BEGIN
  
  -- 定义变量
    DECLARE  _done int default 0;

    -- 出现过的广告数
    DECLARE  publisher_ads int default 0;
    -- 出现过的广告主数
    DECLARE  publisher_advertisers int default 0;
    -- 出现过的跟踪者数
    DECLARE  publisher_trackers int default 0;
    -- 出现过的系列数
    DECLARE  publisher_subjects int default 0;

  DECLARE result CURSOR FOR
      SELECT count(distinct(id)) as ads, count(distinct(subject)) as subjects, count(distinct(advertiser)) as advertisers, count(distinct(tracker)) as trackers FROM main_index WHERE publisher = publisher_id;

  DECLARE CONTINUE HANDLER FOR SQLSTATE '02000' SET _done = 1;#错误定义，标记循环结束
  
    -- 打开光标
  OPEN result;
    REPEAT
      FETCH result INTO publisher_ads, publisher_subjects, publisher_advertisers, publisher_trackers;
      IF NOT _done THEN
        UPDATE domains SET ispublisher = 1, publisher_ads = publisher_ads, publisher_subjects = publisher_subjects, publisher_advertiser = publisher_advertisers, publisher_trackers = publisher_trackers WHERE id = publisher_id;
      END IF;
    UNTIL _done END REPEAT; #_done=1时退出被循
  CLOSE result;
END;

