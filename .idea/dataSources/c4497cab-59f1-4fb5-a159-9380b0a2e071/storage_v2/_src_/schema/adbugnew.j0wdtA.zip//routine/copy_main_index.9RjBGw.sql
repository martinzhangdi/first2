create
    definer = adbug@`%` procedure copy_main_index()
BEGIN
	declare i int;
	declare c int;
	set i = 1;
	select max(index_id) into c from main_index;
	select c;
	while i < c do
		insert ignore into main_index_2 select * from main_index where index_id >= i limit 10000;  
		set i=i+10000;
	end while;
END;

