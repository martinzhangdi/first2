create
    definer = adbug@`%` procedure check_domain_role(IN domain_id int)
BEGIN
  
  -- 定义变量
    DECLARE  _done int default 0;

     -- 现过的广告数
    DECLARE  a_ads int default 0;
    -- 出现过的跟踪者数
    DECLARE  a_trackers int default 0;
    -- 出现过的媒体数
    DECLARE  a_publishers int default 0;
    -- 出现过的系列数
    DECLARE  a_subjects int default 0;

    -- 出现过的广告数
    DECLARE  p_ads int default 0;
    -- 出现过的广告主数
    DECLARE  p_advertisers int default 0;
    -- 出现过的跟踪者数
    DECLARE  p_trackers int default 0;
    -- 出现过的系列数
    DECLARE  p_subjects int default 0;

    -- 现过的广告数
    DECLARE  t_ads int default 0;
    -- 出现过的跟踪者数
    DECLARE  t_advertisers int default 0;
    -- 出现过的媒体数
    DECLARE  t_publishers int default 0;
    -- 出现过的系列数
    DECLARE  t_subjects int default 0;

    -- 角色
    DECLARE  is_advertiser int default 0;
    DECLARE  is_publisher int default 0;
    DECLARE  is_tracker int default 0;

    -- 最终角色
    DECLARE  l_role int default 0;


    -- SELECT brand_ads, publisher_ads, tracker_ads, brand_subjects, publisher_subjects, tracker_subjects, brand_publishers, tracker_publishers, publisher_advertiser, tracker_advertiser, brand_trackers, publisher_trackers, isbrand, ispublisher, istracker FROM domains WHERE id = domain_id;

  DECLARE result CURSOR FOR
    SELECT brand_subjects, publisher_subjects, tracker_advertiser, isbrand, ispublisher, istracker FROM domains WHERE id = domain_id;

  DECLARE CONTINUE HANDLER FOR SQLSTATE '02000' SET _done = 1;#错误定义，标记循环结束
  
    -- 打开光标
  OPEN result;
    REPEAT
      FETCH result INTO a_subjects, p_subjects, t_advertisers, is_advertiser, is_publisher, is_tracker;
      IF NOT _done THEN
        
        -- SELECT p_subjects, a_subjects, t_advertisers;

        IF p_subjects > a_subjects AND p_subjects > t_advertisers THEN
          -- SELECT 'ispublisher';
          SELECT 1 INTO l_role;
        END IF;

        IF a_subjects > p_subjects AND a_subjects > t_advertisers THEN
          -- SELECT 'is_advertiser';
          SELECT 2 INTO l_role;
        END IF;

        IF t_advertisers > p_subjects AND t_advertisers > a_subjects THEN
          -- SELECT 'istracker';
          SELECT 3 INTO l_role;
        END IF;

				
			  IF l_role = 0 THEN
					SELECT 2 INTO l_role;
				END IF;
				
				IF is_advertiser = 0 AND is_publisher = 0 AND is_tracker = 0 THEN
					SELECT 0 INTO l_role;
				END IF;



                -- -- 如果相等
                -- IF p_subjects = a_subjects THEN
                --     -- 如果广告主的系列数大于0
                --     IF a_subjects > 0 THEN
                --         SELECT 2 INTO l_role;
                --     ELSEIF t_advertisers > 0 THEN
                --         SELECT 3 INTO l_role;
                --     END IF;
                -- END IF;

                -- -- 如果相等
                -- IF t_advertisers = a_subjects THEN
                --     -- 如果广告主的系列数大于0
                --     IF a_subjects > 0 THEN
                --         SELECT 2 INTO l_role;
                --     ELSEIF p_subjects < 0 THEN
                --         SELECT 3 INTO l_role;
                --     END IF;
                -- END IF;

                -- -- 如果相等
                -- IF t_advertisers = p_subjects THEN
                --     -- 如果广告主的系列数大于0
                --     IF p_subjects > 0 THEN
                --         SELECT 1 INTO l_role;
                --     ELSEIF a_subjects < 0 THEN
                --         SELECT 3 INTO l_role;
                --     END IF;
                -- END IF;

                -- SELECT l_role;
        UPDATE domains SET role = l_role WHERE id = domain_id;
        -- modify
        -- UPDATE domains SET ispublisher = is_publisher, isbrand = is_advertiser, istracker = is_tracker WHERE id = domain_id;
      END IF;
    UNTIL _done END REPEAT; #_done=1时退出被循
  CLOSE result;
END;

