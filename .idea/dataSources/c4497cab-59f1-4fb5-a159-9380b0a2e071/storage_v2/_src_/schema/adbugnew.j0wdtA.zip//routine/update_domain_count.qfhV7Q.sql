create
    definer = adbug@`%` procedure update_domain_count(IN d_id int)
BEGIN
  CALL update_publisher_count(d_id);
  CALL update_advertiser_count(d_id);
  CALL update_tracker_count(d_id);
END;

