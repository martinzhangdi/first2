create
    definer = adbug@`%` procedure update_publishers_count()
BEGIN
  -- 定义变量
    DECLARE  _done int default 0;

  DECLARE publisher_id int;

  -- 定义光标
    DECLARE _Cur CURSOR FOR
            SELECT DISTINCT(publisher) AS publisher FROM main_index;

  DECLARE CONTINUE HANDLER FOR SQLSTATE '02000' SET _done = 1;#错误定义，标记循环结束
        
  -- 打开光标
    OPEN _Cur;
     -- 循环
         REPEAT
            FETCH _Cur INTO publisher_id;
            IF NOT _done THEN
              IF publisher_id > 0 THEN
          CALL update_publisher_count(publisher_id);
        END IF;
            END IF;
         UNTIL _done END REPEAT; #当_done=1时退出被循
    -- 关闭光标
    CLOSE _Cur;
END;

