create
    definer = adbug@`%` function func_split(f_string text, f_delimiter text, f_order int) returns text
BEGIN
	#Routine body goes here...
	
	declare result text default ''; 

  set result = reverse(substring_index(reverse(substring_index(f_string,f_delimiter,f_order)),f_delimiter,1));
	IF result='""' THEN
	SET result='';
	END IF;

  return result;
END;

