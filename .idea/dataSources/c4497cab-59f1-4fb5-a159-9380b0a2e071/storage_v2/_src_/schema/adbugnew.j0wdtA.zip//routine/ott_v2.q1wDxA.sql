create
    definer = adbug@`%` function ott_v2() returns int
BEGIN
  DECLARE ott_id int default 0;
  DECLARE ott VARCHAR(50); 

	RETURN ott_id;
  SELECT id INTO ott_id FROM otts_copy WHERE host = CONCAT('"',ott_list,'"');

  IF ott_id > 0 THEN
    
    RETURN ott_id;
  ELSE
    
    RETURN ott_id;
  END IF;
END;

