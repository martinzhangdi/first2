create
    definer = adbug@`%` procedure insert_addata_trackers(IN f_string text, IN f_delimiter text, IN id int)
BEGIN
	#Routine body goes here...
	DECLARE ad_isexist_id int DEFAULT 0;
	DECLARE ad_tags text DEFAULT '';

	SELECT id INTO ad_isexist_id from addata_tags where ad_id=id;

	SET ad_tags = get_tags_list(f_string,f_delimiter);

	IF ad_isexist_id > 0 THEN
			UPDATE addata_tags SET trackers_list = ad_tags WHERE ad_id=id;
	ELSEIF ad_isexist_id = 0 THEN
			insert into addata_tags(id,ad_id,trackers_list) values (id,id,ad_tags);
	END IF;
END;

