create
    definer = adbug@`%` procedure up_main_index_type(IN id int)
BEGIN
	#Routine body goes here...
	DECLARE  _done int default 0;
	DECLARE ad_type int DEFAULT 0;
	DECLARE ad_isexist_id int DEFAULT 0;
	DECLARE type_id int DEFAULT 0;
	DECLARE ad_platform int DEFAULT 0;
	DECLARE type_platform int DEFAULT 0;
	DECLARE ad_attr varchar(100) CHARACTER SET utf8;
	DECLARE ad_material varchar(100) CHARACTER SET utf8; 
	#INTO ad_isexist_id,ad_type,ad_attr,ad_material,ad_platform
	DECLARE result CURSOR FOR
					SELECT m.index_id,a.type,a.attribute04,a.material,a.platform  from main_index as m JOIN addata as a ON m.id=a.id  where m.index_id=id;

	DECLARE CONTINUE HANDLER FOR SQLSTATE '02000' SET _done = 1;#错误定义，标记循环结束  
	-- 打开光标
	OPEN result;
			REPEAT
					FETCH result INTO ad_isexist_id,ad_type,ad_attr,ad_material,ad_platform;
					IF NOT _done THEN

								IF ad_type = "image" THEN
										SET type_id = 1;
								END IF;

								IF ad_type = "swf" THEN
										SET type_id = 2;
								END IF;
								
								IF ad_type = "flv" THEN
										SET type_id = 3;
								END IF;

								IF ad_type = "html5" THEN
										SET type_id = 4;
								END IF;

								IF ad_material = "native" THEN
										SET type_id = 5;
								END IF;


								IF ad_platform = 1 THEN
										SET type_platform = 1;
								END IF;
								IF ad_platform = 2 THEN
										SET type_platform = 2;
								END IF;

								
								
								IF ad_attr = "Android" THEN
										SET type_platform = 3;
								END IF;
								IF ad_material = "IOS" THEN
										SET type_platform = 4;
								END IF;

								IF ad_platform = 4 THEN
										SET type_platform = 5;
								END IF;

								UPDATE main_index SET type = 4, platform = type_platform WHERE index_id = id;
					END IF;
			UNTIL _done END REPEAT; #_done=1时退出被循
	CLOSE result;
	SET _done = 0;
END;

