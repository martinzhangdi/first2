create
    definer = adbug@`%` function calc_rank(trackers varchar(1000), created_date bigint, publisher varchar(1000),
                                           ctype varchar(1000), advertiser varchar(1000)) returns decimal(13, 2)
BEGIN
  DECLARE tracker_level int default 0;
  DECLARE type_level int default 0;
  DECLARE advertiser_level int default 0;
  DECLARE publisher_pr int default 0;

  DECLARE rank decimal(13,2) default 0;

  IF ctype = "flv" THEN
  	SET type_level = 3;
  END IF;

  IF ctype = "swf" THEN
  	SET type_level = 2;
  END IF;

  IF ctype = "image" THEN
  	SET type_level = 1;
  END IF;

  SELECT get_trackers_level(trackers) INTO tracker_level;
  SELECT count(*) INTO advertiser_level FROM trackers_level WHERE host = advertiser AND type = "e-commerce";
  SELECT pr INTO publisher_pr FROM host_meta_copy WHERE host = publisher;

  -- insert into logs set content = tracker_level;
  -- insert into logs set content = created_date;
  -- insert into logs set content = publisher_pr;
  -- insert into logs set content = type_level;
  -- insert into logs set content = advertiser_level;

	-- SET rank = (((tracker_level * 0.20) + (created_date / 86400000) + (publisher_pr * 0.15) + (type_level * 0.15) - advertiser_level * 0.4 ) / 6 ) * 1000;
		
  -- SET rank = (((tracker_level * 0.20) + (created_date / 100000000000 * 0.50) + (publisher_pr * 0.15) + (type_level * 0.15) - advertiser_level * 0.4 ) / 6 ) * 1000;
	SET rank = (created_date / 86400000) + advertiser_level * -5 + type_level * 1 + tracker_level * -0.5 + publisher_pr * 0.2;

  RETURN rank;
END;

