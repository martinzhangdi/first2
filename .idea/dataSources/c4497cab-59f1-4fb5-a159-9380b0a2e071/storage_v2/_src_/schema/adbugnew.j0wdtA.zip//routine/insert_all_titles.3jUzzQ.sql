create
    definer = adbug@`%` procedure insert_all_titles()
BEGIN
	-- 定义变量
    DECLARE  _done int default 0;
	DECLARE  otitle varchar(1000) CHARACTER SET utf8;

	-- 定义光标
    DECLARE _Cur CURSOR FOR
            SELECT DISTINCT(title) AS title FROM subjects;

	DECLARE CONTINUE HANDLER FOR SQLSTATE '02000' SET _done = 1;#错误定义，标记循环结束
				
	-- 打开光标
    OPEN _Cur;
		 -- 循环
         REPEAT
            FETCH _Cur INTO otitle;
            IF NOT _done THEN
            	INSERT ignore INTO titles SET title = otitle, title_md5 = MD5(otitle);
            END IF;
         UNTIL _done END REPEAT; #当_done=1时退出被循
		-- 关闭光标
    CLOSE _Cur;
END;

