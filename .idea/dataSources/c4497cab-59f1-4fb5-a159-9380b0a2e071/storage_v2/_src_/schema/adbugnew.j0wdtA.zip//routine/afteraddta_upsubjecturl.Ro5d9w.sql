create
    definer = adbug@`%` procedure afteraddta_upsubjecturl(IN qtitle varchar(255), IN qadvertiser varchar(255),
                                                          IN attr08 varchar(255), IN qtype varchar(255))
BEGIN
	#Routine body goes here...
	DECLARE subject_id int default 0;
  DECLARE subject_md5 VARCHAR(50); 
	DECLARE subject_url VARCHAR(50); 

  SELECT MD5(CONCAT(qtitle, qadvertiser)) INTO subject_md5;
  SELECT id INTO subject_id FROM subjects WHERE md5 = subject_md5;
	SELECT html5_url INTO subject_url FROM subjects WHERE md5 = subject_md5;


	IF qtype = "html5" AND subject_url='' THEN
		SET subject_url = attr08;
	END IF;

	IF qtype = "html5" AND subject_id>0 AND subject_url='' THEN
			UPDATE subjects SET html5_url = subject_url WHERE id = subject_id;
	END IF;
	
END;

