create
    definer = adbug@`%` function get_host_id(qhost varchar(1000)) returns int
BEGIN
  DECLARE host_id int default 0;  
  #SELECT id INTO host_id FROM domains WHERE host = qhost;
	SELECT id INTO host_id FROM domains WHERE md5 = MD5(TRIM(qhost));
  IF host_id > 0 THEN
    RETURN host_id;
  ELSE
    INSERT INTO domains SET host = TRIM(qhost), md5 = MD5(TRIM(qhost));
    SELECT LAST_INSERT_ID() INTO host_id FROM domains LIMIT 1;
    RETURN host_id;
  END IF;
END;

