create
    definer = adbug@`%` procedure cptable()
begin
	declare i int;
	declare c int;
	set i = 1;
	select max(id) into c from addata;
  select max(id) into i from addata_new;
	select c;
	while i < c do
		-- insert ignore into addata_new(id,x,y,width,height,thumb_width,thumb_height,cookie,size,domain,subject_md5,title,keywords,metas,trackers,tags,platform,type,original_url,thumb_url,share_url,target_url,thumbnail,last_seen,md5,audit,status,views,created_date,modified_date,machine_location,machine_ip,shape,advertiser,publisher,parent,screen_height,screen_width,body_height,body_width,depth,iframes,attribute01,attribute02,attribute03,attribute04,attribute05,attribute06,attribute07,attribute08,url,session_id, screen, url_md5) select id,x,y,width,height,thumb_width,thumb_height,cookie,size,domain,subject_md5,title,keywords,metas,trackers,tags,platform,type,original_url,thumb_url,share_url,target_url,thumbnail,last_seen,md5,audit,status,views,created_date,modified_date,machine_location,machine_ip,shape,advertiser,publisher,parent,screen_height,screen_width,body_height,body_width,depth,iframes,attribute01,attribute02,attribute03,attribute04,attribute05,attribute06,attribute07,attribute08,url,session_id,IF(platform = 2,  0,  y /  IF(screen_height = 0,  1080,  screen_height)) as screen, MD5(original_url) as url_md5 from addata where id >= i limit 10000;  
    insert ignore into addata_new select * from addata where id >= i limit 10000;
		set i=i+10000;
	end while;
end;

