create
    definer = adbug@`%` function test_attr07(ad_id int) returns text
BEGIN
	#Routine body goes here...
	DECLARE ad_isexist_id int DEFAULT 0;
	DECLARE ad_tags text DEFAULT '';
	DECLARE att07 text DEFAULT '';
	declare cnt int default 0; 

	declare i int default 0;
	declare j int default 0; 
	DECLARE  _done int default 0; 

	SELECT attribute07 INTO att07 from addata where id=ad_id;


	set cnt = func_split_TotalLength(att07,','); 

	while i < cnt 
	do 
			set i = i + 1; 
			#set ad_tags = CONCAT('"',func_split(f_string,f_delimiter,i),'"');
			IF i = cnt THEN
			set ad_tags = CONCAT(ad_tags,func_split(att07,',',i));
			ELSE
			set ad_tags = CONCAT(ad_tags,func_split(att07,',',i),',');
			END IF;
	end while;
	SET i = 0;

	RETURN ad_tags;

END;

