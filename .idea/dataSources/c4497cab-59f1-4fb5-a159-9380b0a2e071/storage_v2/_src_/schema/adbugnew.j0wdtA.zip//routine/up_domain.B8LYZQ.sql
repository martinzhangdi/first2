create
    definer = adbug@`%` procedure up_domain(IN d_id int)
BEGIN
	#Routine body goes here...
	replace into domainsup(id,host,`for`,flag,
cname,ename,isbrand,ispublisher,istracker,platform,brand_ads,
publisher_ads,tracker_ads,brand_subjects
,publisher_subjects,tracker_subjects,brand_publishers,tracker_publishers,
publisher_advertiser,tracker_advertiser,
brand_trackers,publisher_trackers,md5,rank,role,have_desc,logo,have_logo,have_favicon,attr01,attr02,brand_safety,publisher_safety,tracker_safety,brand_screen,brand_volume,publisher_screen,tracker_screen,tracker_tags,attr04) 
select id,host,`for`,flag,cname,ename,isbrand,ispublisher,istracker,platform,brand_ads,publisher_ads,tracker_ads,brand_subjects,
publisher_subjects,tracker_subjects,brand_publishers,tracker_publishers,publisher_advertiser,tracker_advertiser,
brand_trackers,publisher_trackers,md5,rank,role,have_desc,logo,have_logo,have_favicon,attr01,attr02,brand_safety,publisher_safety,tracker_safety,brand_screen,brand_volume,publisher_screen,tracker_screen,tracker_tags,attr04 from domains WHERE domains.id=d_id;

END;

