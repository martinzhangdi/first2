create
    definer = adbug@`%` procedure update_advertiser_count(IN advertiser_id int)
BEGIN
  
  -- 定义变量
    DECLARE  _done int default 0;

    -- 现过的广告数
    DECLARE  advertiser_ads int default 0;
    -- 出现过的跟踪者数
    DECLARE  advertiser_trackers int default 0;
    -- 出现过的媒体数
    DECLARE  advertiser_publishers int default 0;
    -- 出现过的系列数
    DECLARE  advertiser_subjects int default 0;

  DECLARE result CURSOR FOR
      SELECT count(distinct(id)) as ads, count(distinct(subject)) as subjects, count(distinct(publisher)) as publishers, count(distinct(tracker)) as trackers FROM main_index WHERE advertiser = advertiser_id;

  DECLARE CONTINUE HANDLER FOR SQLSTATE '02000' SET _done = 1;#错误定义，标记循环结束
  
    -- 打开光标
  OPEN result;
    REPEAT
      FETCH result INTO advertiser_ads, advertiser_subjects, advertiser_publishers, advertiser_trackers;
      IF NOT _done THEN
        UPDATE domains SET isbrand = 1, brand_ads = advertiser_ads, brand_subjects = advertiser_subjects, brand_publishers = advertiser_publishers, brand_trackers = advertiser_trackers WHERE id = advertiser_id;
      END IF;
    UNTIL _done END REPEAT; #_done=1时退出被循
  CLOSE result;
END;

