create
    definer = adbug@`%` function get_trackers_cats(trackers varchar(1000)) returns varchar(1000)
BEGIN

   -- 定义变量
    DECLARE  _done int default 0;
    DECLARE level int default 0;
    DECLARE maxlevel int default 5;
    -- 跟踪者
    DECLARE  tracker varchar(100) CHARACTER SET utf8 default NULL;
		DECLARE  last_tracker varchar(100) CHARACTER SET utf8;

    DECLARE tracker_cats varchar(1000) CHARACTER SET utf8;
    DECLARE tracker_cat varchar(100) CHARACTER SET utf8;


    -- 定义光标
   DECLARE _Cur CURSOR FOR
            SELECT  SUBSTRING( str,xh, LOCATE(';',CONCAT(trackers,';'), xh) -xh) AS splitstr FROM Num as a, ( SELECT trackers AS str ) b WHERE a.xh <= LENGTH(  str)  AND SUBSTRING( CONCAT(';',str), xh, 1) = ';' ;
	 
	 DECLARE CONTINUE HANDLER FOR NOT FOUND SET _done = 1;#错误定义，标记循环结束
		
	 SET _done = 0;

  -- 打开光标
    OPEN _Cur;
        -- 循环
        dept_loop:REPEAT
            FETCH _Cur INTO tracker;
            IF tracker IS NULL THEN
               SET tracker = NULL;
            ELSE
                SELECT get_tracker_cats(tracker) INTO tracker_cat;
                SET tracker_cats = CONCAT_WS(";", tracker_cats, tracker_cat);
            END IF;
            SET tracker = NULL;
        UNTIL _done 
		END REPEAT dept_loop;

    CLOSE _Cur;
		SET _done = 0;

    RETURN tracker_cats;
END;

