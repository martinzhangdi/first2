create
    definer = adbug@`%` procedure update_advertiser_rank(IN advertiser_id int)
BEGIN
    
    -- 定义变量
    DECLARE  _done int default 0;

    -- 出现过的广告数
    DECLARE  trackers_ads int default 0;
    DECLARE  video_ads int default 0;

    DECLARE  rank_score int default 0;

    DECLARE result CURSOR FOR
            SELECT id FROM main_index WHERE advertiser = advertiser_id  AND tracker IN(89, 96) LIMIT 1;

    DECLARE flv_result CURSOR FOR
            SELECT addata.id FROM main_index LEFT JOIN addata ON main_index.id  = addata.id WHERE main_index.advertiser = advertiser_id AND addata.type = 'flv' LIMIT 1;

    DECLARE CONTINUE HANDLER FOR SQLSTATE '02000' SET _done = 1;#错误定义，标记循环结束
    
    -- 打开光标
    OPEN result;
        REPEAT
            FETCH result INTO trackers_ads;
            IF NOT _done THEN
                IF trackers_ads > 0 THEN
                    SET rank_score = rank_score +20;
                END IF;
            END IF;
        UNTIL _done END REPEAT; #_done=1时退出被循
    CLOSE result;

    SET _done = 0;

    OPEN flv_result;
        REPEAT
            FETCH flv_result INTO video_ads;
            IF NOT _done THEN
                IF video_ads > 0 THEN
                    SET rank_score = rank_score +40;
                END IF;
            END IF;
        UNTIL _done END REPEAT; #_done=1时退出被循
    CLOSE flv_result;

    UPDATE domains SET rank =  rank_score WHERE id = advertiser_id;
END;

