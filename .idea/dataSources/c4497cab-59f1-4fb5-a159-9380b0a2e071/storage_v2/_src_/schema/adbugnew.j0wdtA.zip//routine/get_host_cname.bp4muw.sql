create
    definer = adbug@`%` function get_host_cname(qhost varchar(1000)) returns varchar(1000)
BEGIN
  DECLARE host_cname varchar(1000) CHARACTER SET utf8;
  SELECT cname INTO host_cname FROM domains_copy WHERE host = qhost;
  RETURN host_cname;
END;

