create
    definer = adbug@`%` procedure update_publisher_metas(IN publisher_id int)
BEGIN
    -- 不安全占比
    DECLARE apublisher_brandsafety decimal(11, 3) default 0;
    -- 平均屏次
    DECLARE apublisher_screen decimal(11, 3) default 0;

	SELECT (SUM(original_urls.risk_3) / count(*) * 100), (SUM(addata_new.screen) / count(*)) INTO apublisher_brandsafety, apublisher_screen FROM main_index LEFT JOIN addata_new on addata_new.id = main_index.id LEFT JOIN original_urls on original_urls.md5 = addata_new.url_md5 WHERE main_index.platform = 1 AND main_index.publisher = publisher_id;
   	
   	UPDATE domains SET publisher_safety = apublisher_brandsafety, publisher_screen = apublisher_screen WHERE id = publisher_id;
END;

