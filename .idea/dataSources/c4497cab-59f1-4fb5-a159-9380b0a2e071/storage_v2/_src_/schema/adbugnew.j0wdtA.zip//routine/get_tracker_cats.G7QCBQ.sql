create
    definer = adbug@`%` function get_tracker_cats(qhost varchar(1000)) returns varchar(1000)
BEGIN
	DECLARE tracker_cat varchar(100) CHARACTER SET utf8 default NULL;
  SELECT cats INTO tracker_cat FROM domain_cats WHERE host = qhost limit 1;
  RETURN tracker_cat;
END;

