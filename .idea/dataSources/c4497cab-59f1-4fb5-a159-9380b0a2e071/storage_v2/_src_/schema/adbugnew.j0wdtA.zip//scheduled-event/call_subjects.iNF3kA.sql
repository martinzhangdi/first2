create definer = ding2@`%` event call_subjects on schedule
    every '1' DAY
        starts '2016-12-06 01:00:00'
    on completion preserve
    enable
    do
    call update_subjects_count();

