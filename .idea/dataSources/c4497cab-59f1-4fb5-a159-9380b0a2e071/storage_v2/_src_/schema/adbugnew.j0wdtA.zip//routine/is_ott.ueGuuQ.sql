create
    definer = adbug@`%` function is_ott() returns text
BEGIN
	#Routine body goes here...
	RETURN (SELECT domain FROM otts);
END;

