create definer = adbug@`%` trigger afterinsert_on_addata
    after insert
    on addata_old
    for each row
BEGIN
    CALL new_ad(
        NEW.advertiser, 
        NEW.publisher, 
        NEW.id, 
        NEW.trackers, 
        NEW.platform, 
        NEW.type, 
        NEW.shape, 
        get_subject_id(NEW.id, NEW.title, NEW.advertiser, NEW.created_date, CONCAT('http://file.adbug.cn', '/datasync/', NEW.domain, '/thumb/', IFNULL(NEW.thumbnail, NEW.thumb_url)), NEW.target_url, NEW.thumb_width, NEW.thumb_height),
        NEW.width,
        NEW.height,
        NEW.created_date,
        NEW.md5
    );
END;

