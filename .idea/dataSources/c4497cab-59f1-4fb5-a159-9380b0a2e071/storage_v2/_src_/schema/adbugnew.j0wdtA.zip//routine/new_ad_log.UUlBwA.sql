create
    definer = adbug@`%` procedure new_ad_log(IN imd5 varchar(100), IN icreated_date bigint)
BEGIN
    -- 定义变量
    DECLARE  _done int default 0;
    DECLARE  _rct int default 0;

    DECLARE  advertiser_id int default 0;
    DECLARE  subject_id int default 0;
    DECLARE  publisher_id int default 0;
    DECLARE  tracker_id int default 0;
    DECLARE  platform_id int default 0;
    DECLARE  placement_id int default 0;
    DECLARE  ad_id int default 0;
    DECLARE  type_id int default 0;
    DECLARE  a_width int default 0;
    DECLARE  a_height int default 0;
    DECLARE  a_shape int default 0;
    DECLARE  a_device int default 0;
    DECLARE  a_geo int default 0;
    DECLARE  a_foa int default 0;

    DECLARE  exiets_id int default 0;
    
    SELECT 
        advertiser, publisher, id, subject, tracker, type, platform, shape, placement, device, width, height, geo  
    INTO advertiser_id, publisher_id, ad_id, subject_id, tracker_id, type_id, platform_id, a_shape, placement_id, a_device, a_width, a_height, a_geo FROM main_index_mobile WHERE md5 = imd5 LIMIT 1;

    IF ad_id != 0 THEN


        SELECT id INTO exiets_id FROM main_index_mobile WHERE id = ad_id AND created_date = icreated_date AND child = 1;

        IF exiets_id = 0 THEN
            INSERT INTO main_index_mobile
                SET publisher = publisher_id, 
                    advertiser = advertiser_id, 
                    tracker = tracker_id, 
                    subject = subject_id, 
                    id = ad_id, 
                    platform = platform_id, 
                    type = type_id, 
                    shape = a_shape, 
                    placement = placement_id, 
                    width = a_width, 
                    md5 = imd5,
                    created_date = icreated_date,
                    child = 1,
                    day = FROM_UNIXTIME(icreated_date / 1000, "%Y%m%d"),
                    height = a_height;
        END IF;

    END IF;
END;

