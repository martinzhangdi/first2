create
    definer = adbug@`%` procedure fix_new_ad(IN ad_id bigint)
BEGIN
	declare title_1 varchar(100) CHARACTER SET utf8; 
	declare advertiser_1 varchar(100) CHARACTER SET utf8; 
	declare publisher_1 varchar(100) CHARACTER SET utf8; 	 
	declare trackers_1 varchar(2000) CHARACTER SET utf8;
	declare target_url_1 varchar(2000) CHARACTER SET utf8;
	declare platform_1 int;
	declare type_1 varchar(100); 
	declare shape_1 int; 
	declare subject_id int;
	declare width_1 int;
	declare height_1 int;
	declare created_date_1 bigint;
	declare md5_1 varchar(100);
	declare attribute04_1 varchar(100); 
	declare material_1 varchar(100);

	select title,target_url,advertiser, 
        publisher,         
        trackers, 
        platform, 
        type, 
        shape, 
        
        width,
        height,
        created_date,
        md5,
       attribute04,
       material into title_1,target_url_1,advertiser_1, 
        publisher_1,         
        trackers_1, 
        platform_1, 
        type_1, 
        shape_1, 
        
        width_1,
        height_1,
        created_date_1,
        md5_1,
       attribute04_1,
       material_1 from addata_2018 where id =ad_id limit 1; 

CALL new_ad(
        advertiser_1, 
        publisher_1, 
        ad_id, 
        trackers_1, 
        platform_1, 
        type_1, 
        shape_1, 
        get_subject_id(ad_id, title_1, advertiser_1, created_date_1, null, target_url_1, 0, 0),
        width_1,
        height_1,
        created_date_1,
        md5_1,
        attribute04_1,
        material_1
    );

END;

