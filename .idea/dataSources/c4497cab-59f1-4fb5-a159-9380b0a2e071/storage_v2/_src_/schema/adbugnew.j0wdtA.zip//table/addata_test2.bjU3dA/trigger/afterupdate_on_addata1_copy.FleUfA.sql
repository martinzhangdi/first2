create definer = ding2@`%` trigger afterupdate_on_addata1_copy
    after update
    on addata_test2
    for each row
BEGIN
    -- INSERT INTO test_logs SET log = CONCAT('update_ad_', NEW.id);
    CALL update_ad(
        NEW.advertiser, 
        NEW.publisher, 
        NEW.id, 
        NEW.trackers, 
        NEW.platform, 
        NEW.type, 
        NEW.shape, 
        get_subject_id(NEW.id, NEW.title, NEW.advertiser, NEW.created_date, CONCAT('http://file.adbug.cn', '/datasync/', NEW.domain, '/thumb/', IFNULL(NEW.thumbnail, NEW.thumb_url)), NEW.target_url, NEW.thumb_width, NEW.thumb_height),
        NEW.width,
        NEW.height,
        NEW.created_date,
        NEW.attribute04,
        NEW.material

    );
END;

