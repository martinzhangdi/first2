create
    definer = adbug@`%` procedure up_addata_tags()
BEGIN
	#Routine body goes here...
	
	
	declare cnt int default 0; 

	declare i int default 0;
	declare j int default 0; 
	DECLARE ad_tags text DEFAULT '';

	DECLARE ad_id_tags int DEFAULT 0;
	DECLARE ad_isexist_id int DEFAULT 0;
	DECLARE ad_num int DEFAULT 0;
	DECLARE  _done int default 0; 
/* max id: 11240075*/
	DECLARE _Cur CURSOR FOR  
					SELECT id,tags from addata WHERE id<11170716 AND id>11160120;

	DECLARE CONTINUE HANDLER FOR SQLSTATE '02000' SET _done = 1;#错误定义，标记循环结束  


	OPEN _Cur;  
         /* 循环执行 */  
         REPEAT  
            FETCH _Cur INTO ad_id_tags, ad_tags;  
						IF NOT _done THEN  
								
								IF INSTR(ad_tags,';') > 0 THEN

									CALL insert_addata_tags(ad_tags,";",ad_id_tags);

								ELSEIF INSTR(ad_tags,',') > 0 THEN

									CALL insert_addata_tags(ad_tags,",",ad_id_tags);

								ELSE
									
									CALL insert_tags2(ad_tags,",",ad_id_tags);
									#IF INSTR(ad_tags,',') > 0 THEN
										#	insert into addata_tags(id,ad_id,tags) values (ad_id_tags,ad_id_tags,ad_tags);
									#ELSE
										#insert into addata_tags(id,ad_id,tags) values (ad_id_tags,ad_id_tags,CONCAT('"',ad_tags,'"'));
									#END IF;
								END IF;
								
            END IF;  
         UNTIL _done END REPEAT; #当_done=1时退出被循  
    /*关闭光标*/  
   CLOSE _Cur;
	 SET _done = 0;
END;

