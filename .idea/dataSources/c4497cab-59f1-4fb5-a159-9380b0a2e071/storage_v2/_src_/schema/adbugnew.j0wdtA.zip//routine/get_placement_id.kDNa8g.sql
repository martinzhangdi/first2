create
    definer = adbug@`%` function get_placement_id(qpublisher varchar(1000), qwidth int(13), qheight int(13)) returns int
BEGIN
  DECLARE pid int default 0;
  DECLARE qplacement VARCHAR(50);

  SET qplacement = CONCAT(TRIM(qpublisher), '_', qwidth, "x", qheight);

  SELECT id INTO pid FROM placement WHERE name = qplacement;
  IF pid > 0 THEN
    RETURN pid;
  ELSE
    INSERT INTO placement SET name = qplacement, publisher = qpublisher, width = qwidth, height = qheight;
    SELECT LAST_INSERT_ID() INTO pid FROM placement LIMIT 1;
    RETURN pid;
  END IF;
END;

