create definer = ding2@`%` trigger afterinsert_on_addata2
    after insert
    on addata_2018
    for each row
BEGIN
    CALL new_ad(
        NEW.advertiser, 
        NEW.publisher, 
        NEW.id, 
        NEW.trackers, 
        NEW.platform, 
        NEW.type, 
        NEW.shape, 
        get_subject_id(NEW.id, NEW.title, NEW.advertiser, NEW.created_date, null, NEW.target_url, 0, 0),
        NEW.width,
        NEW.height,
        NEW.created_date,
        NEW.md5,
       NEW.attribute04,
       NEW.material
    );
END;

