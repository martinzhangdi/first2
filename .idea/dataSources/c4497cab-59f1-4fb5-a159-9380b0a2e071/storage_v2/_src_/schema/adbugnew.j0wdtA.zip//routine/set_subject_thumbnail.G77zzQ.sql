create
    definer = adbug@`%` procedure set_subject_thumbnail(IN subject_id int)
BEGIN
  
  -- 定义变量
    DECLARE  _done int default 0;

    DECLARE thumbnail_url VARCHAR(500); 
  DECLARE shape int;

  DECLARE  width int default 0;
  DECLARE  height int default 0;

  DECLARE Shape_result CURSOR FOR
      SELECT addata.shape, CONCAT('http://file.adbug.cn', '/datasync/', addata.domain, '/thumb/', addata.thumbnail) AS thumbnail_url, addata.thumb_width, addata.thumb_height  FROM main_index LEFT JOIN addata ON addata.id = main_index.id WHERE subject = subject_id GROUP BY addata.shape;

  DECLARE CONTINUE HANDLER FOR SQLSTATE '02000' SET _done = 1;#错误定义，标记循环结束
  
    -- 打开光标
  OPEN Shape_result;
    REPEAT
      FETCH Shape_result INTO shape, thumbnail_url, width, height;
      IF NOT _done THEN
        IF shape = 2 THEN
          UPDATE subjects SET thumbnail = thumbnail_url, thumb_height = height, thumb_width = width WHERE id = subject_id;
          SET _done = 1;
        END IF;

        IF shape = 1 THEN 
          UPDATE subjects SET thumbnail = thumbnail_url, thumb_height = height, thumb_width = width WHERE id = subject_id;
          SET _done = 1;
        END IF;

        IF shape = 3 THEN 
          UPDATE subjects SET thumbnail = thumbnail_url, thumb_height = height, thumb_width = width WHERE id = subject_id;
          SET _done = 1;
        END IF;

        IF shape = 4 THEN 
          UPDATE subjects SET thumbnail = thumbnail_url, thumb_height = height, thumb_width = width WHERE id = subject_id;
          SET _done = 1;
        END IF;

        IF shape = 5 THEN 
          UPDATE subjects SET thumbnail = thumbnail_url, thumb_height = height, thumb_width = width WHERE id = subject_id;
          SET _done = 1;
        END IF;

        IF shape = 0 THEN 
          UPDATE subjects SET thumbnail = thumbnail_url, thumb_height = height, thumb_width = width WHERE id = subject_id;
          SET _done = 1;
        END IF;
      END IF;
    UNTIL _done END REPEAT; #_done=1时退出被循
  CLOSE Shape_result;
END;

