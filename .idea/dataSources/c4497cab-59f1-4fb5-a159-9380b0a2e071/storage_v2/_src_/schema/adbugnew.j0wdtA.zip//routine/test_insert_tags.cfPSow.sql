create
    definer = adbug@`%` function test_insert_tags(f_string text, f_delimiter text, id int) returns text
BEGIN
	#Routine body goes here...
	DECLARE ad_isexist_id int DEFAULT 0;
	DECLARE ad_tags text DEFAULT '';
	declare cnt int default 0; 

	declare i int default 0;
	declare j int default 0; 
	DECLARE  _done int default 0; 
	DECLARE  new_tags text default '';
	DECLARE  new_tags_tmp text default '';

	SELECT id INTO ad_isexist_id from addata_tags where ad_id=id;

	set cnt = func_split_TotalLength(f_string,f_delimiter); 


	while i < cnt 
	do 
			set i = i + 1; 
			set new_tags_tmp = func_split(f_string,f_delimiter,i);
			
			IF new_tags_tmp='""' THEN
			SET new_tags_tmp = '';
			END IF;

			IF i = cnt THEN
				IF INSTR(new_tags_tmp,'"') > 0 THEN
					set ad_tags = CONCAT(ad_tags,func_split(f_string,f_delimiter,i));
				ELSE
					set ad_tags = CONCAT(ad_tags,',','"',func_split(f_string,f_delimiter,i),'"');
				END IF;
			ELSE

			IF INSTR(new_tags_tmp,'"') > 0 THEN
			set ad_tags = CONCAT(ad_tags,func_split(f_string,f_delimiter,i),',');
			ELSE
			set ad_tags = CONCAT(ad_tags,'"',func_split(f_string,f_delimiter,i),'",');
			END IF;

			END IF;
			
	end while;
	SET i = 0;
	

	RETURN ad_tags;
	
END;

