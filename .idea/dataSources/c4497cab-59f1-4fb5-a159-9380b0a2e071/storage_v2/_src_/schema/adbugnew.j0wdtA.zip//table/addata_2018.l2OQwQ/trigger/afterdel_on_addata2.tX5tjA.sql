create definer = ding2@`%` trigger afterdel_on_addata2
    after delete
    on addata_2018
    for each row
BEGIN
    CALL del_ad(OLD.id);
END;

