create
    definer = adbug@`%` procedure up_ad_title_attr(IN adid int)
BEGIN

	
	#Routine body goes here...
	DECLARE ad_isexis_id int DEFAULT 0;
	
	
	DECLARE ad_domain varchar(100) CHARACTER SET utf8;

	DECLARE ad_title varchar(100) CHARACTER SET utf8;


	SELECT id INTO ad_isexis_id from addata_ott where ad_id = adid;

	SELECT domain ,attribute05 INTO ad_domain,ad_title FROM addata_2018 WHERE id=adid;


	IF ad_domain = 'com.mitv.tvhome' THEN
		#INTO ad_isexist_id
		

		IF ad_isexis_id = 0 THEN

				insert into addata_ott(ad_id,title) values (adid,ad_title);
		ELSE

				UPDATE addata_ott SET title = ad_title WHERE ad_id=adid;
		END IF;

	END IF;

	IF ad_domain = 'com.himedia.mg' THEN
		#INTO ad_isexist_id
		

		IF ad_isexis_id = 0 THEN

				insert into addata_ott(ad_id,title) values (adid,ad_title);
		ELSE

				UPDATE addata_ott SET title = ad_title WHERE ad_id=adid;
		END IF;

	END IF;


	IF ad_domain = 'com.letv.tv' THEN
		#INTO ad_isexist_id
		

		IF ad_isexis_id = 0 THEN

				insert into addata_ott(ad_id,title) values (adid,ad_title);
		ELSE

				UPDATE addata_ott SET title = ad_title WHERE ad_id=adid;
		END IF;

	END IF;

END;

