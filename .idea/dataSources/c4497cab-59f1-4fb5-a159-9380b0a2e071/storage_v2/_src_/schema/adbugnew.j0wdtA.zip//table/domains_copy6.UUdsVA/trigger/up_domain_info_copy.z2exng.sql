create definer = adbug@`%` trigger up_domain_info_copy
    after update
    on domains_copy6
    for each row
BEGIN
    CALL up_domain(
        NEW.id
    );
END;

