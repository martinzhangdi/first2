create
    definer = adbug@`%` procedure update_subjects_thumbnail()
BEGIN
  -- 定义变量
    DECLARE  _done int default 0;

    DECLARE subject_result_done int default 0;

  DECLARE subject_id int;
  DECLARE thumbnail_url VARCHAR(500); 
  DECLARE shape int;

  -- 定义光标
    DECLARE _Cur CURSOR FOR
            SELECT id FROM subjects;
    DECLARE CONTINUE HANDLER FOR SQLSTATE '02000' SET _done = 1;#错误定义，标记循环结束
        
  -- 打开光标
    OPEN _Cur;
     -- 循环
         REPEAT
            FETCH _Cur INTO subject_id;
            IF NOT _done THEN
              IF subject_id > 0 THEN
          CALL set_subject_thumbnail(subject_id);
        END IF;
            END IF;
         UNTIL _done END REPEAT; #当_done=1时退出被循
    -- 关闭光标
    CLOSE _Cur;
END;

