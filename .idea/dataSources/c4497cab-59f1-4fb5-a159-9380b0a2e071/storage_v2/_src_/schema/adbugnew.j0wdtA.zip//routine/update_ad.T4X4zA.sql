create
    definer = adbug@`%` procedure update_ad(IN advertiser varchar(100), IN publisher varchar(100), IN ad_id int,
                                            IN trackers varchar(2000), IN nplatform_id int, IN type varchar(100),
                                            IN nshape int, IN subject_id int, IN width int, IN height int,
                                            IN created_date bigint, IN attribute04 varchar(100),
                                            IN material varchar(100))
BEGIN
    -- 定义变量
    DECLARE  _done int default 0;
    DECLARE  _rct int default 0;
    -- 广告主ID
    DECLARE  advertiser_id int default 0;
    -- 媒体ID
    DECLARE  publisher_id int default 0;
    -- 跟踪者ID
    DECLARE  tracker_id int default 0;
    -- 跟踪者ID
    DECLARE  platform_id int default 0;
	
		-- DECLARE up_ad_num int DEFAULT 0;

    -- 跟踪者ID
    DECLARE  type_id int default 0;
    -- 跟踪者
    DECLARE  tracker varchar(100) CHARACTER SET utf8;
    DECLARE  placement_id int default 0;


		
		-- DECLARE ad_domain varchar(100) CHARACTER SET utf8;
		-- DECLARE ad_title varchar(100) CHARACTER SET utf8;

 
    SELECT get_host_id(advertiser) INTO advertiser_id;
    SELECT get_host_id(publisher) INTO publisher_id;
    SELECT get_placement_id(publisher, width, height) INTO placement_id;

		-- CALL up_ad_title_attr(ad_id);

    -- 如果是空的就设为0
    SELECT IFNULL(nplatform_id, 1) INTO platform_id;

    IF type = "image" THEN
        SET type_id = 1;
    END IF;

    IF type = "swf" THEN
        SET type_id = 2;
    END IF;
    
    IF type = "flv" THEN
        SET type_id = 3;
    END IF;
		IF type = "html5" THEN
        SET type_id = 4;
    END IF;
		IF material = 'native' THEN
			 SET type_id = 5;
		END IF;

		IF nplatform_id = 1 THEN
			 SET platform_id = 1;
    END IF;

		IF nplatform_id = 2 THEN
			 SET platform_id = 2;
    END IF;

		IF attribute04 = "Android" THEN
			 SET platform_id = 3;
    END IF;

		IF attribute04 = "IOS" THEN
			 SET platform_id = 4;
    END IF;

		IF nplatform_id = 4 THEN
			 SET platform_id = 5;
    END IF;
    
    -- 更新
    UPDATE main_index 
    SET publisher = publisher_id, 
        advertiser = advertiser_id, 
        subject = subject_id, 
        platform = platform_id, 
        type = type_id, 
        shape = nshape, 
        placement = placement_id, 
        width = width, 
        created_date = created_date, 
        height = height 
        WHERE id = ad_id;
END;

