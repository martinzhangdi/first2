create
    definer = adbug@`%` procedure update_main_index_subject()
BEGIN
  -- 定义变量
    DECLARE  _done int default 0;

    DECLARE old_subject_id int default 0;
  DECLARE new_subject_id int default 0;
  DECLARE ad_id int default 0;

  DECLARE a_index_id int default 0;

  -- 定义光标
    DECLARE _Cur CURSOR FOR
           SELECT main_index.subject,main_index.index_id, get_subject_id(addata.id, addata.title, addata.advertiser,addata.created_date, CONCAT('http://file.adbug.cn', '/datasync/', addata.domain, '/thumb/', IFNULL(addata.thumbnail, addata.thumb_url)), addata.target_url,addata.thumb_width,addata.thumb_height) AS new_subject FROM main_index  LEFT JOIN addata ON addata.id = main_index.id WHERE main_index.id < 840680;

  DECLARE CONTINUE HANDLER FOR SQLSTATE '02000' SET _done = 1;#错误定义，标记循环结束
        
  -- 打开光标
    OPEN _Cur;
     -- 循环
         REPEAT
            FETCH _Cur INTO old_subject_id, a_index_id ,new_subject_id;
            IF NOT _done THEN
              IF old_subject_id <> new_subject_id AND new_subject_id > 0 THEN
          UPDATE main_index SET subject = new_subject_id WHERE index_id = a_index_id;
        END IF;
            END IF;
         UNTIL _done END REPEAT; #当_done=1时退出被循
    -- 关闭光标
    CLOSE _Cur;
END;

