create definer = adbug@`%` trigger trigger_after_update
    after update
    on addata_hour_trend
    for each row
begin
    INSERT INTO `addata_trend2` (domain, fingerprint, daytime, times) VALUES (NEW.domain, NEW.fingerprint, NEW.daytime, 1) ON DUPLICATE KEY UPDATE times = times + 1;
end;

