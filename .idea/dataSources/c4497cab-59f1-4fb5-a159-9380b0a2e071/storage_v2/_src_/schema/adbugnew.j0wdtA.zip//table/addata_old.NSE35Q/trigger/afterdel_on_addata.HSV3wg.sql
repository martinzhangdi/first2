create definer = adbug@`%` trigger afterdel_on_addata
    after delete
    on addata_old
    for each row
BEGIN
    CALL del_ad(OLD.id);
END;

