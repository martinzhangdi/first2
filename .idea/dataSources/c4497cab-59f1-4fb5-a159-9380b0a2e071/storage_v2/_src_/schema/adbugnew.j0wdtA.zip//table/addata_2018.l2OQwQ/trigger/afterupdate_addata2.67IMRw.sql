create definer = adbug@`%` trigger afterupdate_addata2
    after update
    on addata_2018
    for each row
BEGIN
    -- INSERT INTO test_logs SET log = CONCAT('update_ad_', NEW.id);
    CALL update_ad(
        NEW.advertiser, 
        NEW.publisher, 
        NEW.id, 
        NEW.trackers, 
        NEW.platform, 
        NEW.type, 
        NEW.shape, 
        get_subject_id(NEW.id, NEW.title, NEW.advertiser, NEW.created_date, null, NEW.target_url, 0, 0),
        NEW.width,
        NEW.height,
        NEW.created_date,
        NEW.attribute04,
        NEW.material

    );
END;

