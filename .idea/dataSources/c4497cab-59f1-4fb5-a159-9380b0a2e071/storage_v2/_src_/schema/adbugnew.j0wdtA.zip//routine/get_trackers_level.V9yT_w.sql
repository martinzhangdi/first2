create
    definer = adbug@`%` function get_trackers_level(trackers varchar(1000)) returns int
BEGIN

   -- 定义变量
    DECLARE  _done int default 0;
    DECLARE level int default 0;
    DECLARE maxlevel int default 5;
    -- 跟踪者
    DECLARE  tracker varchar(100) CHARACTER SET utf8;


    -- 定义光标
   DECLARE _Cur CURSOR FOR
            SELECT  SUBSTRING( str,xh, LOCATE(';',CONCAT(trackers,';'), xh) -xh) AS splitstr FROM Num as a, ( SELECT trackers AS str ) b WHERE a.xh <= LENGTH(  str)  AND SUBSTRING( CONCAT(';',str), xh, 1) = ';' ;
        DECLARE CONTINUE HANDLER FOR SQLSTATE '02000' SET _done = 1;#错误定义，标记循环结束
    
    DECLARE CONTINUE HANDLER FOR SQLSTATE '23000' SET _done = 1;


  -- 打开光标
    OPEN _Cur;
         -- 循环
         REPEAT
            FETCH _Cur INTO tracker;
            
            SELECT get_tracker_level(tracker) INTO level;
            
            IF level < maxlevel THEN
              SET maxlevel = level;
            END IF;
         UNTIL _done END REPEAT;

    CLOSE _Cur;

    RETURN maxlevel;

END;

