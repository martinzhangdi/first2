create definer = ding@`%` event call_domain_role on schedule
    every '1' DAY
        starts '2016-12-06 01:00:00'
    on completion preserve
    enable
    do
    call check_new_domains_role();

