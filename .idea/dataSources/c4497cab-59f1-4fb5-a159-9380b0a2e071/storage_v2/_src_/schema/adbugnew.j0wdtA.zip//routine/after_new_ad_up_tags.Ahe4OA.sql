create
    definer = adbug@`%` procedure after_new_ad_up_tags(IN ad_id int)
BEGIN
	#Routine body goes here...
	
	
	declare cnt int default 0; 

	declare i int default 0;
	declare j int default 0; 
	DECLARE ad_tags text DEFAULT '';
	DECLARE ad_trackers text DEFAULT '';

	-- DECLARE ad_domain varchar(100) CHARACTER SET utf8;

	-- DECLARE ad_title varchar(100) CHARACTER SET utf8;

	DECLARE ad_id_tags int DEFAULT 0;
	DECLARE ad_isexist_id int DEFAULT 0;
	DECLARE ad_num int DEFAULT 0;
	DECLARE  _done int default 0; 
/* max id: 11160120*/

	SELECT id,tags,trackers INTO ad_id_tags, ad_tags,ad_trackers from addata_2018 WHERE id=ad_id;


	# tags 
	IF INSTR(ad_tags,';') > 0 THEN
		CALL insert_addata_tags(ad_tags,";",ad_id_tags);
	ELSEIF INSTR(ad_tags,',') > 0 THEN
		CALL insert_addata_tags(ad_tags,",",ad_id_tags);
	ELSE
		CALL insert_tags2(ad_tags,",",ad_id_tags);
	END IF;
	# trackers
	IF INSTR(ad_trackers,';') > 0 THEN
		CALL insert_addata_trackers(ad_trackers,";",ad_id_tags);
	ELSEIF INSTR(ad_trackers,',') > 0 THEN
		CALL insert_addata_trackers(ad_trackers,",",ad_id_tags);
	ELSE
		CALL insert_trackers(ad_trackers,",",ad_id_tags);
	END IF;
END;

