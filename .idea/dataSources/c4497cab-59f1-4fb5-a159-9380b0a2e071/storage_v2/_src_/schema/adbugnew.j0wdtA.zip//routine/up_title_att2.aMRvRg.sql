create
    definer = adbug@`%` function up_title_att2(ad_domain text) returns int
BEGIN

	
	#Routine body goes here...
	DECLARE ad_isexis_id int DEFAULT 0;
	
	
	DECLARE ad_domain varchar(100) CHARACTER SET utf8;

	DECLARE ad_title varchar(100) CHARACTER SET utf8;




	IF ad_domain = "com.mitv.tvhome" THEN
		#INTO ad_isexist_id
		

		RETURN 1;

	END IF;


	RETURN 0;

END;

