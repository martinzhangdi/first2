create definer = adbug@`%` trigger afterinsert_on_addata_md5
    after insert
    on addata_md5
    for each row
BEGIN
    -- INSERT INTO test_logs SET log = CONCAT('update_ad_', NEW.id);
    CALL new_ad_log(
        NEW.md5, 
        NEW.created_date
    );
END;

