create
    definer = adbug@`%` procedure update_advertiser_metastt(IN advertiser_id int)
BEGIN
	
	-- 定义变量
    DECLARE  _done int default 0;
    -- 不安全占比
    DECLARE  advertiser_brandsafety decimal(11, 3) default 0;
    -- 平均屏次
    DECLARE  advertiser_screen decimal(11, 3) default 0;
    -- 平均声量
    DECLARE  advertiser_volume decimal(11, 3) default 0;

	SELECT (SUM(original_urls.risk_3) / count(*) * 100)  as brand_safety, (SUM(addata_new.screen) / count(*))  as brand_screen, (SUM(addata_new.volume) / count(*))  as brand_volume INTO advertiser_brandsafety, advertiser_screen, advertiser_volume FROM main_index LEFT JOIN addata_new on addata_new.id = main_index.id LEFT JOIN original_urls on original_urls.md5 = addata_new.url_md5 WHERE main_index.platform = 1 AND main_index.advertiser = advertiser_id;
   	UPDATE domains SET brand_safety = advertiser_brandsafety, brand_screen = advertiser_screen, brand_volume = advertiser_volume WHERE id = advertiser_id;
END;

