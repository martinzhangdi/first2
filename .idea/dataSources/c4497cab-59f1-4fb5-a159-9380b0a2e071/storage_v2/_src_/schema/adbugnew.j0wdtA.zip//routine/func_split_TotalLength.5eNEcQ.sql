create
    definer = adbug@`%` function func_split_TotalLength(f_string text, f_delimiter text) returns int
BEGIN 
		SET f_string = trim(f_string);
    # 计算传入字符串的总length 
    return 1+(length(f_string) - length(replace(f_string,f_delimiter,''))); 

END;

