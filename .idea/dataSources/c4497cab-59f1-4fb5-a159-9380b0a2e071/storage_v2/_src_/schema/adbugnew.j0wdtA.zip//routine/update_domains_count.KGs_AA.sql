create
    definer = adbug@`%` procedure update_domains_count()
BEGIN
  CALL update_publishers_count();
  CALL update_advertisers_count();
  CALL update_trackers_count();
END;

