create
    definer = adbug@`%` function get_host_ename(qhost varchar(1000)) returns varchar(1000)
BEGIN
  DECLARE host_ename varchar(1000) CHARACTER SET utf8;
  SELECT ename INTO host_ename FROM domains_copy WHERE host = qhost;
  RETURN host_ename;
END;

