create
    definer = adbug@`%` procedure update_tracker_metas(IN tracker_id int)
BEGIN
    -- 不安全占比
    DECLARE atracker_brandsafety decimal(11, 3) default 0;
    -- 平均屏次
    DECLARE atracker_screen decimal(11, 3) default 0;

	SELECT (SUM(original_urls.risk_3) / count(*) * 100), (SUM(addata_new.screen) / count(*)) INTO atracker_brandsafety, atracker_screen FROM main_index LEFT JOIN addata_new on addata_new.id = main_index.id LEFT JOIN original_urls on original_urls.md5 = addata_new.url_md5 WHERE main_index.platform = 1 AND main_index.tracker = tracker_id;
   	
   	UPDATE domains SET tracker_safety = atracker_brandsafety, tracker_screen = atracker_screen WHERE id = tracker_id;
END;

