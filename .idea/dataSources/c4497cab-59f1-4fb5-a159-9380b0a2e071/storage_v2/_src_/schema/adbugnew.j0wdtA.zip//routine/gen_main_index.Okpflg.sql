create
    definer = ding2@`%` procedure gen_main_index(IN bid int)
BEGIN

   DECLARE done INT DEFAULT FALSE;
   DECLARE _advertiser varchar(100);
   DECLARE _publisher varchar(100);
   DECLARE _id int default 0;
   DECLARE _trackers varchar(500);
   DECLARE _platform int;
   DECLARE _type varchar(100);
   DECLARE _shape int;
   DECLARE _subject_id int;
   DECLARE _width int;
   DECLARE _height int;
   DECLARE _created_date bigint;
   DECLARE _md5 varchar(100);

   DECLARE c1 CURSOR FOR
     SELECT advertiser, 
        publisher, 
        id, 
        trackers, 
        platform, 
        type, 
        shape, 
        get_subject_id(id, title, advertiser, created_date, CONCAT('http://file.adbug.cn', '/datasync/', domain, '/thumb/', IFNULL(thumbnail, thumb_url)), target_url, thumb_width, thumb_height) subject_id,
        width,
        height,
        created_date,
        md5
     FROM addata_new
     WHERE id >= bid limit 1000000;

   DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;

   OPEN c1;		
    REPEAT
			FETCH c1 INTO _advertiser, 
					_publisher, 
					_id, 
					_trackers, 
					_platform, 
					_type, 
					_shape, 
					_subject_id,
					_width,
					_height,
					_created_date,
					_md5;
			-- select _md5;
			call new_ad_2(_advertiser, 
				_publisher, 
				_id, 
				_trackers, 
				_platform, 
				_type, 
				_shape, 
				_subject_id,
				_width,
				_height,
				_created_date,
				_md5);		
			
    UNTIL done END REPEAT;
   CLOSE c1;
	 -- return _id;
END;

