create
    definer = adbug@`%` procedure update_tracker_count(IN tracker_id int)
BEGIN
  
  -- 定义变量
    DECLARE  _done int default 0;

    -- 现过的广告数
    DECLARE  tracker_ads int default 0;
    -- 出现过的跟踪者数
    DECLARE  tracker_advertisers int default 0;
    -- 出现过的媒体数
    DECLARE  tracker_publishers int default 0;
    -- 出现过的系列数
    DECLARE  tracker_subjects int default 0;

  DECLARE result CURSOR FOR
      SELECT count(distinct(id)) as ads, count(distinct(subject)) as subjects, count(distinct(publisher)) as publishers, count(distinct(advertiser)) as advertisers FROM main_index WHERE tracker = tracker_id;

  DECLARE CONTINUE HANDLER FOR SQLSTATE '02000' SET _done = 1; #错误定义，标记循环结束
  
    -- 打开光标
  OPEN result;
    REPEAT
      FETCH result INTO tracker_ads, tracker_subjects, tracker_publishers, tracker_advertisers;
      IF NOT _done THEN
        UPDATE domains SET istracker = 1, tracker_ads = tracker_ads, tracker_subjects = tracker_subjects, tracker_publishers = tracker_publishers, tracker_advertiser = tracker_advertisers WHERE id = tracker_id;
      END IF;
    UNTIL _done END REPEAT; #_done=1时退出被循
  CLOSE result;
END;

