create definer = ding2@`%` trigger afterdel_on_addata1_copy
    after delete
    on addata_test2
    for each row
BEGIN
    CALL del_ad(OLD.id);
END;

