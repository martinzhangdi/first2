create
    definer = adbug@`%` procedure update_domain_metas(IN domain_id int)
BEGIN
	CALL update_advertiser_metas(domain_id);
	CALL update_publisher_metas(domain_id);
	CALL update_tracker_metas(domain_id);
END;

