create definer = adbug@`%` trigger up_domain_info
    after update
    on domains
    for each row
BEGIN
    CALL up_domain(
        NEW.id
    );
END;

