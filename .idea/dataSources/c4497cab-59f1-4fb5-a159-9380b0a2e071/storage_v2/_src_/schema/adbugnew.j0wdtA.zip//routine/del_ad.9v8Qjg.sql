create
    definer = adbug@`%` procedure del_ad(IN ad_id int)
BEGIN
    -- 定义变量
    DECLARE  _done int default 0;
    DELETE FROM main_index WHERE id = ad_id;
END;

