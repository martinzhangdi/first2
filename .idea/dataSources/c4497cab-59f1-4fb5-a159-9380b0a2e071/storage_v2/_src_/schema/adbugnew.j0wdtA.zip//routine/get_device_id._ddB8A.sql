create
    definer = adbug@`%` function get_device_id(type varchar(100)) returns int
BEGIN
    DECLARE device_id int default 1;

    IF type = "IOS" THEN
        SET device_id = 2;
    END IF;

    RETURN device_id;
END;

