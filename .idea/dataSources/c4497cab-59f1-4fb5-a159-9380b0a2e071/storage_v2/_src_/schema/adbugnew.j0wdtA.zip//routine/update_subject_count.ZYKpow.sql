create
    definer = adbug@`%` procedure update_subject_count(IN subject_id int)
BEGIN
  
  -- 定义变量
    DECLARE  _done int default 0;

    -- 出现过的广告数
    DECLARE  subject_ads int default 0;
    -- 出现过的广告主数
    DECLARE  subject_publishers int default 0;
    -- 出现过的跟踪者数
    DECLARE  subject_trackers int default 0;
    -- 出现过的系列数
    DECLARE  subject_videos int default 0;

    DECLARE  subject_platform int default 0;

    DECLARE  max_id int default 0;

    DECLARE  subject_all_trackers text default "";

    

  DECLARE result CURSOR FOR
      select count(distinct(main_index.id)) as ads, count(distinct(main_index.publisher)) as publishers, (select count(distinct(main_index.tracker)) from main_index where subject = subject_id and tracker > 0)  as trackers, (select count(distinct(main_index.id)) from main_index where subject = subject_id and type = 3)  as videos, (select count(distinct(main_index.id)) from main_index where subject = subject_id and platform = 2)  as platform, max(main_index.id) as max_id, group_concat(trackers separator ";") as all_trackers from main_index left join addata on addata.id = main_index.id where main_index.subject = subject_id group by subject;

  DECLARE CONTINUE HANDLER FOR SQLSTATE '02000' SET _done = 1;#错误定义，标记循环结束
  
    -- 打开光标
  OPEN result;
    REPEAT
      FETCH result INTO subject_ads, subject_publishers, subject_trackers, subject_videos, subject_platform, max_id, subject_all_trackers;
      IF NOT _done THEN

        IF subject_videos > 0 THEN
          select 1 INTO subject_videos;
        END IF;

        IF subject_platform > 0 THEN
          select 1 INTO subject_platform;
        END IF;

        IF max_id > 0 THEN
          UPDATE subjects SET ads = subject_ads, publishers = subject_publishers, trackers = subject_trackers, have_mobile = subject_platform, have_video = subject_videos, last_detected = (select created_date from addata where id = max_id), all_trackers = subject_all_trackers WHERE id = subject_id;
        END IF;
      END IF;
    UNTIL _done END REPEAT; #_done=1时退出被循
  CLOSE result;
END;

