create definer = adbug@`%` trigger up_domain_info_copy1
    after update
    on domains_copy7
    for each row
BEGIN
    CALL up_domain(
        NEW.id
    );
END;

