create
    definer = adbug@`%` function get_tags_list(f_string text, f_delimiter text) returns text
BEGIN
	#Routine body goes here...
	
	DECLARE ad_tags text DEFAULT '';
	declare cnt int default 0; 

	declare i int default 0;
	DECLARE  new_tags_tmp text default '';


	set cnt = func_split_TotalLength(f_string,f_delimiter); 


	while i < cnt 
	do 
			set i = i + 1; 
			set new_tags_tmp = func_split(f_string,f_delimiter,i);
			
			IF new_tags_tmp='""' THEN
			SET new_tags_tmp = '';
			END IF;

			IF i = cnt THEN
				IF INSTR(new_tags_tmp,'"') > 0 THEN
					set ad_tags = CONCAT(ad_tags,func_split(f_string,f_delimiter,i));
				ELSE
					set ad_tags = CONCAT(ad_tags,'"',func_split(f_string,f_delimiter,i),'"');
				END IF;
			ELSE

			IF INSTR(new_tags_tmp,'"') > 0 THEN
			set ad_tags = CONCAT(ad_tags,func_split(f_string,f_delimiter,i),',');
			ELSE
			set ad_tags = CONCAT(ad_tags,'"',func_split(f_string,f_delimiter,i),'",');
			END IF;

			END IF;
			
	end while;
	SET i = 0;
	RETURN ad_tags;
	
END;

