create
    definer = adbug@`%` procedure new_ad(IN advertiser varchar(100), IN publisher varchar(100), IN ad_id int,
                                         IN trackers varchar(2000), IN nplatform_id int, IN type varchar(100),
                                         IN nshape int, IN subject_id int, IN width int, IN height int,
                                         IN created_date bigint, IN md5 varchar(100), IN attribute04 varchar(100),
                                         IN material varchar(100))
BEGIN
    -- 定义变量
    DECLARE  _done int default 0;
    DECLARE  _rct int default 0;
    -- 广告主ID
    DECLARE  advertiser_id int default 0;
    -- 媒体ID
    DECLARE  publisher_id int default 0;
    -- 跟踪者ID
    DECLARE  tracker_id int default 0;
    -- 跟踪者ID
    DECLARE  platform_id int default 0;
    -- 跟踪者ID
    DECLARE  placement_id int default 0;

    -- 跟踪者ID
    DECLARE  type_id int default 0;
    -- 跟踪者
    DECLARE  tracker varchar(100) CHARACTER SET utf8;

    -- 定义光标
    DECLARE _Cur CURSOR FOR
            SELECT  SUBSTRING( str,xh, LOCATE(';',CONCAT(trackers,';'), xh) -xh) AS splitstr FROM adbugnew.Num a, ( SELECT trackers AS str )b WHERE a.xh <= LENGTH(  str)  AND SUBSTRING( CONCAT(';',str), xh, 1) = ';' ;
        DECLARE CONTINUE HANDLER FOR SQLSTATE '02000' SET _done = 1;#错误定义，标记循环结束
    
    DECLARE CONTINUE HANDLER FOR SQLSTATE '23000' SET _done = 1;


    SELECT get_host_id(advertiser) INTO advertiser_id;
    SELECT get_host_id(publisher) INTO publisher_id;
    SELECT get_placement_id(publisher, width, height) INTO placement_id;
	
		CALL after_new_ad_up_tags(ad_id);
		
		-- 小米盒子添加 addata_ott
		CALL up_ad_title_attr(ad_id);

    -- 如果是空的就设为0
    SELECT IFNULL(nplatform_id, 1) INTO platform_id;

    IF type = "image" THEN
        SET type_id = 1;
    END IF;

    IF type = "swf" THEN
        SET type_id = 2;
    END IF;
    
    IF type = "flv" THEN
        SET type_id = 3;
    END IF;
		-- finn 2017-4-17
		IF type = "html5" THEN
       SET type_id = 4;
    END IF;
		IF material = 'native' THEN
			 SET type_id = 5;
		END IF;

		 

		IF nplatform_id = 1 THEN
			 SET platform_id = 1;
    END IF;

		IF nplatform_id = 2 THEN
			 SET platform_id = 2;
    END IF;

		


		IF attribute04 = "Android" THEN
			 SET platform_id = 3;
    END IF;

		IF attribute04 = "IOS" THEN
			 SET platform_id = 4;
    END IF;


		IF nplatform_id = 4 THEN
			 SET platform_id = 5;
    END IF;
    
    -- 打开光标
    OPEN _Cur;
         -- 循环
         REPEAT
            FETCH _Cur INTO tracker;
            IF NOT _done THEN
                SELECT get_host_id(tracker) INTO tracker_id;
                IF tracker_id > 0 THEN
                    SET _rct = _rct+1;
                    INSERT INTO main_index SET publisher = publisher_id, advertiser = advertiser_id, tracker = tracker_id, subject = subject_id, id = ad_id, platform = platform_id, type = type_id, shape = nshape, placement = placement_id, width = width, created_date = created_date, height = height, md5 = md5;
                    IF platform_id = 2 THEN
                        INSERT INTO main_index_mobile SET publisher = publisher_id, advertiser = advertiser_id, tracker = tracker_id, subject = subject_id, id = ad_id, platform = platform_id, type = type_id, shape = nshape, placement = placement_id, width = width, created_date = created_date, day = FROM_UNIXTIME(created_date / 1000, "%Y%m%d"), height = height, md5 = md5;
                    END IF;

                END IF;
            END IF;
         UNTIL _done END REPEAT; #当_done=1时退出被循
        -- 关闭光标
    CLOSE _Cur;

    IF _rct = 0 THEN
        INSERT INTO main_index SET publisher = publisher_id, advertiser = advertiser_id, tracker = tracker_id, subject = subject_id, id = ad_id, platform = platform_id, type = type_id, shape = nshape, placement = placement_id, width = width, created_date = created_date, height = height, md5 = md5;
        IF platform_id = 2 THEN
            INSERT INTO main_index_mobile SET publisher = publisher_id, advertiser = advertiser_id, tracker = tracker_id, subject = subject_id, id = ad_id, platform = platform_id, type = type_id, shape = nshape, placement = placement_id, width = width, created_date = created_date, day = FROM_UNIXTIME(created_date / 1000, "%Y%m%d"), height = height, md5 = md5;
        END IF;
    END IF;
END;

