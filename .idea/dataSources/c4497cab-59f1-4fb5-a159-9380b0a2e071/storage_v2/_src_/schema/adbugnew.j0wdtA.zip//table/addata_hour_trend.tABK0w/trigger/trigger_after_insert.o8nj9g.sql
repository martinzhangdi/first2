create definer = ding2@`%` trigger trigger_after_insert
    after insert
    on addata_hour_trend
    for each row
begin
    INSERT INTO `addata_trend2` (domain, fingerprint, daytime, times) VALUES (NEW.domain, NEW.fingerprint, NEW.daytime, 1) ON DUPLICATE KEY UPDATE times = times + 1;
end;

