create
    definer = adbug@`%` procedure update_domains_metas()
BEGIN
	-- 定义变量
    DECLARE  _done int default 0;

	DECLARE domain_id int;

	-- 定义光标
    DECLARE _Cur CURSOR FOR
            SELECT id FROM domains;

	DECLARE CONTINUE HANDLER FOR SQLSTATE '02000' SET _done = 1;#错误定义，标记循环结束
				
	-- 打开光标
    OPEN _Cur;
		 -- 循环
         REPEAT
            FETCH _Cur INTO domain_id;
            IF NOT _done THEN
            	IF domain_id > 0 THEN
					CALL update_domain_metas(domain_id);
				END IF;
            END IF;
         UNTIL _done END REPEAT; #当_done=1时退出被循
		-- 关闭光标
    CLOSE _Cur;
END;

