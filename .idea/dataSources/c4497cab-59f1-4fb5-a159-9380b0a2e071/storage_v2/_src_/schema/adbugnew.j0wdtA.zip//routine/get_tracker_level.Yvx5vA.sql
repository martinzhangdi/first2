create
    definer = adbug@`%` function get_tracker_level(qhost varchar(1000)) returns int
BEGIN
  DECLARE host_id int default 0;
  SELECT level INTO host_id FROM trackers_level WHERE host = qhost limit 1;
  RETURN host_id;
END;

