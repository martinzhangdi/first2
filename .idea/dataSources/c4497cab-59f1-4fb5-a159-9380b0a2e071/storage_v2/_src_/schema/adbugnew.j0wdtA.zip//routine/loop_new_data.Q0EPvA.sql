create
    definer = ding2@`%` procedure loop_new_data()
begin
	declare i int;
  declare curId int;

	set i = 1;
	while i <> 0 do
		select gen_main_index(i) into curId;
		set i = curId;
	end while;
end;

