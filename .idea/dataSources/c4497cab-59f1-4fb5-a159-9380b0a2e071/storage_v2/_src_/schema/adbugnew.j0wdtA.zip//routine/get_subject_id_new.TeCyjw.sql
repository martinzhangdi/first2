create
    definer = adbug@`%` function get_subject_id_new(qad_id int(13), qtitle varchar(300), qadvertiser varchar(100),
                                                    qcreated_date bigint(15), qthumbnail varchar(5000),
                                                    qtarget_url varchar(5000), qthumb_width int(4),
                                                    qthumb_height int(4)) returns int
BEGIN
  DECLARE subject_id int default 0;
  DECLARE subject_md5 VARCHAR(50); 
  SELECT MD5(CONCAT(qtitle, qadvertiser)) INTO subject_md5;
  SELECT id INTO subject_id FROM subjects WHERE md5 = subject_md5;
  IF subject_id > 0 THEN
    UPDATE subjects SET last_detected = qcreated_date WHERE id = subject_id and last_detected < qcreated_date;
    RETURN subject_id;
  ELSE
    SET names utf8;
    INSERT INTO subjects SET ad_id = qad_id, md5 = subject_md5, title = qtitle, advertiser = ( SELECT get_host_id(qadvertiser)), first_detected = qcreated_date, last_detected = qcreated_date, target_url = qtarget_url, thumbnail = qthumbnail, thumb_width = qthumb_width, thumb_height = qthumb_height;
    SELECT LAST_INSERT_ID() INTO subject_id FROM subjects LIMIT 1;
    RETURN subject_id;
  END IF;
END;

